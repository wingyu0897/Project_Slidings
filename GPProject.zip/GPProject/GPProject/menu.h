#pragma once

int gameMenu();
int keyController();
int gameOver();