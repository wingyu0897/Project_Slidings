#pragma once

int gameMode();
int keyCont();