#include "EffectTrail.h"

EffectTrail::EffectTrail(int life, POINT position) : life{ life }, position{ position }
{
}

EffectTrail::~EffectTrail()
{
}
